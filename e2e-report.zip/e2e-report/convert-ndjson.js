const { Formatter } = require('cucumber-json-report-formatter');
const fs = require('fs');

const formatter = new Formatter();
const sourceFile = './cypress/cucumber-json/cucumber-messages.ndjson';
const outputFile = './cypress/cucumber-json/cucumber-report.json';

formatter.parseCucumberJson(sourceFile, outputFile)
  .then(() => console.log('✅ Arquivo JSON convertido com sucesso!'))
  .catch(err => console.error('❌ Erro ao converter o arquivo JSON:', err));
